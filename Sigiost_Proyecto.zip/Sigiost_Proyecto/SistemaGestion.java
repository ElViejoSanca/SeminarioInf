// SistemaGestion.java
import java.util.ArrayList;
import java.util.List;

public class SistemaGestion {

    private List<Sucursal> sucursales;
    private List<Cliente> clientes;
    private List<Tecnico> tecnicos;
    private List<Ticket> tickets;
    private List<OrdenServicio> ordenes;
    private List<ItemInventario> inventario;

    // Constructor
    public SistemaGestion() {
        this.sucursales = new ArrayList<>();
        this.clientes = new ArrayList<>();
        this.tecnicos = new ArrayList<>();
        this.tickets = new ArrayList<>();
        this.ordenes = new ArrayList<>();
        this.inventario = new ArrayList<>();
    }

    // ========================
    // MÉTODOS DE ALTA
    // ========================

    public void agregarSucursal(Sucursal sucursal) {
        if (sucursal == null) {
            throw new IllegalArgumentException("La sucursal no puede ser nula");
        }
        sucursales.add(sucursal);
    }

    public void agregarCliente(Cliente cliente) {
        if (cliente == null) {
            throw new IllegalArgumentException("El cliente no puede ser nulo");
        }
        clientes.add(cliente);
    }

    public void agregarTecnico(Tecnico tecnico) {
        if (tecnico == null) {
            throw new IllegalArgumentException("El técnico no puede ser nulo");
        }
        tecnicos.add(tecnico);
    }

    public void agregarTicket(Ticket ticket) {
        if (ticket == null) {
            throw new IllegalArgumentException("El ticket no puede ser nulo");
        }
        tickets.add(ticket);
    }

    public void agregarOrden(OrdenServicio orden) {
        if (orden == null) {
            throw new IllegalArgumentException("La orden no puede ser nula");
        }
        ordenes.add(orden);
    }

    public void agregarItem(ItemInventario item) {
        if (item == null) {
            throw new IllegalArgumentException("El item no puede ser nulo");
        }
        inventario.add(item);
    }

    // ========================
    // MÉTODOS DE BÚSQUEDA
    // ========================

    public Cliente buscarClientePorId(int id) {
        for (Cliente c : clientes) {
            if (c.getIdCliente() == id) {
                return c;
            }
        }
        return null;
    }

    public Tecnico buscarTecnicoPorId(int id) {
        for (Tecnico t : tecnicos) {
            if (t.getId() == id) {
                return t;
            }
        }
        return null;
    }

    public Ticket buscarTicketPorId(int id) {
        for (Ticket t : tickets) {
            if (t.getIdTicket() == id) {
                return t;
            }
        }
        return null;
    }

    public OrdenServicio buscarOrdenPorNumero(String numeroOrden) {
        for (OrdenServicio o : ordenes) {
            if (o.getNumeroOrden().equalsIgnoreCase(numeroOrden)) {
                return o;
            }
        }
        return null;
    }

    public ItemInventario buscarItemPorCodigo(String codigo) {
        for (ItemInventario item : inventario) {
            if (item.getCodigo().equalsIgnoreCase(codigo)) {
                return item;
            }
        }
        return null;
    }

    public Sucursal buscarSucursalPorId(int id) {
        for (Sucursal s : sucursales) {
            if (s.getIdSucursal() == id) {
                return s;
            }
        }
        return null;
    }

    // Búsqueda de técnicos por nombre (búsqueda parcial)
    public List<Tecnico> buscarTecnicosPorNombre(String nombre) {
        List<Tecnico> resultado = new ArrayList<>();
        for (Tecnico t : tecnicos) {
            if (t.getNombreCompleto().toLowerCase()
                .contains(nombre.toLowerCase())) {
                resultado.add(t);
            }
        }
        return resultado;
    }

    // Búsqueda de técnicos por sucursal
    public List<Tecnico> buscarTecnicosPorSucursal(int idSucursal) {
        List<Tecnico> resultado = new ArrayList<>();
        for (Tecnico t : tecnicos) {
            if (t.getSucursal().getIdSucursal() == idSucursal && t.isActivo()) {
                resultado.add(t);
            }
        }
        return resultado;
    }

    // Búsqueda de órdenes por estado
    public List<OrdenServicio> buscarOrdenesPorEstado(EstadoOrden estado) {
        List<OrdenServicio> resultado = new ArrayList<>();
        for (OrdenServicio o : ordenes) {
            if (o.getEstadoActual() == estado) {
                resultado.add(o);
            }
        }
        return resultado;
    }

    // Items con stock bajo el mínimo
    public List<ItemInventario> obtenerItemsStockBajo() {
        List<ItemInventario> resultado = new ArrayList<>();
        for (ItemInventario item : inventario) {
            if (item.verificarStockMinimo()) {
                resultado.add(item);
            }
        }
        return resultado;
    }

    // Items de inventario por sucursal
    public List<ItemInventario> buscarInventarioPorSucursal(int idSucursal) {
        List<ItemInventario> resultado = new ArrayList<>();
        for (ItemInventario item : inventario) {
            if (item.getSucursal().getIdSucursal() == idSucursal) {
                resultado.add(item);
            }
        }
        return resultado;
    }

    // ========================
    // ALGORITMOS DE ORDENACIÓN
    // ========================

    // Ordena técnicos por cantidad de órdenes activas (burbuja)
    public List<Tecnico> ordenarTecnicosPorCarga() {
        List<Tecnico> lista = new ArrayList<>(tecnicos);
        int n = lista.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (lista.get(j).getOrdenesActivas() >
                    lista.get(j + 1).getOrdenesActivas()) {
                    Tecnico temp = lista.get(j);
                    lista.set(j, lista.get(j + 1));
                    lista.set(j + 1, temp);
                }
            }
        }
        return lista;
    }

 // Ordena ordenes por prioridad (burbuja descendente)
public List<OrdenServicio> ordenarOrdenesPorPrioridad() {
    List<OrdenServicio> lista = new ArrayList<>(ordenes);
    int n = lista.size();
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (lista.get(j).getPrioridad().ordinal() 
                < lista.get(j + 1).getPrioridad().ordinal()) {
                OrdenServicio temp = lista.get(j);
                lista.set(j, lista.get(j + 1));
                lista.set(j + 1, temp);
            }
        }
    }
    return lista;
}

    // ========================
    // GETTERS DE LISTAS
    // ========================

    public List<Sucursal> getSucursales() { return sucursales; }
    public List<Cliente> getClientes() { return clientes; }
    public List<Tecnico> getTecnicos() { return tecnicos; }
    public List<Ticket> getTickets() { return tickets; }
    public List<OrdenServicio> getOrdenes() { return ordenes; }
    public List<ItemInventario> getInventario() { return inventario; }
}
// UsuarioSistema.java
public abstract class UsuarioSistema extends PersonaSistema {

    private static int contadorId = 1;

    private int idUsuario;
    private String username;
    private String password;
    private String rol;
    private boolean activo;

    // Constructor
    public UsuarioSistema(String nombre, String apellido, String telefono,
                          String username, String password, String rol) {
        super(nombre, apellido, telefono);
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("El username no puede estar vacío");
        }
        if (password == null || password.length() < 6) {
            throw new IllegalArgumentException("La contraseña debe tener al menos 6 caracteres");
        }
        this.idUsuario = contadorId++;
        this.username = username;
        this.password = password;
        this.rol = rol;
        this.activo = true;
    }

    // Verifica credenciales de acceso
    public boolean autenticar(String usernameIngresado, String passwordIngresada) {
        if (usernameIngresado == null || passwordIngresada == null) {
            throw new IllegalArgumentException("Las credenciales no pueden ser nulas");
        }
        return this.username.equals(usernameIngresado) &&
               this.password.equals(passwordIngresada) &&
               this.activo;
    }

    // Getters y Setters
    @Override
    public int getId() { return idUsuario; }

    public int getIdUsuario() { return idUsuario; }

    public String getUsername() { return username; }
    public void setUsername(String username) {
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("El username no puede estar vacío");
        }
        this.username = username;
    }

    // Password no tiene getter por seguridad, solo setter
    public void setPassword(String password) {
        if (password == null || password.length() < 6) {
            throw new IllegalArgumentException("La contraseña debe tener al menos 6 caracteres");
        }
        this.password = password;
    }

    protected String getPassword() { return password; }

    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }
}
// Main.java
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static Scanner scanner = new Scanner(System.in);
    private static SistemaGestion sistema = new SistemaGestion();
    private static Coordinador coordinadorActivo;

    public static void main(String[] args) {

        inicializarDatos();

        System.out.println("================================================");
        System.out.println("  SIGIOST - Sistema de Gestión de Órdenes       ");
        System.out.println("  Obercom - NEA Argentina                        ");
        System.out.println("================================================");

        int opcion = -1;
        do {
            mostrarMenuPrincipal();
            try {
                opcion = scanner.nextInt();
                scanner.nextLine();
                procesarOpcionPrincipal(opcion);
            } catch (InputMismatchException e) {
                System.out.println("Error: ingrese un número válido.");
                scanner.nextLine();
            }
        } while (opcion != 0);

        System.out.println("Sistema cerrado. Hasta luego.");
        scanner.close();
    }

    // ========================
    // MENÚ PRINCIPAL
    // ========================

    private static void mostrarMenuPrincipal() {
        System.out.println("\n--- MENÚ PRINCIPAL ---");
        System.out.println("1. Módulo Técnicos");
        System.out.println("2. Módulo Órdenes de Servicio");
        System.out.println("3. Módulo Inventario");
        System.out.println("0. Salir");
        System.out.print("Seleccione una opción: ");
    }

    private static void procesarOpcionPrincipal(int opcion) {
        switch (opcion) {
            case 1: menuTecnicos(); break;
            case 2: menuOrdenes(); break;
            case 3: menuInventario(); break;
            case 0: break;
            default:
                System.out.println("Opción inválida. Intente nuevamente.");
        }
    }

    // ========================
    // MÓDULO TÉCNICOS
    // ========================

    private static void menuTecnicos() {
        int opcion = -1;
        do {
            System.out.println("\n--- MÓDULO TÉCNICOS ---");
            System.out.println("1. Registrar técnico");
            System.out.println("2. Listar técnicos por sucursal");
            System.out.println("3. Buscar técnico por nombre");
            System.out.println("4. Ver carga de trabajo de técnicos");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            try {
                opcion = scanner.nextInt();
                scanner.nextLine();
                switch (opcion) {
                    case 1: registrarTecnico(); break;
                    case 2: listarTecnicosPorSucursal(); break;
                    case 3: buscarTecnicoPorNombre(); break;
                    case 4: verCargaTecnicos(); break;
                    case 0: break;
                    default: System.out.println("Opción inválida.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Error: ingrese un número válido.");
                scanner.nextLine();
            }
        } while (opcion != 0);
    }

    private static void registrarTecnico() {
        System.out.println("\n-- Registrar Técnico --");
        try {
            System.out.print("Nombre: ");
            String nombre = scanner.nextLine();
            System.out.print("Apellido: ");
            String apellido = scanner.nextLine();
            System.out.print("Teléfono: ");
            String telefono = scanner.nextLine();
            System.out.print("Username: ");
            String username = scanner.nextLine();
            System.out.print("Password: ");
            String password = scanner.nextLine();
            System.out.print("Especialización (GENERAL/FTTH/WIRELESS/NETWORKING): ");
            String especializacion = scanner.nextLine().toUpperCase();

            System.out.println("Sucursales disponibles:");
            for (Sucursal s : sistema.getSucursales()) {
                System.out.println("  " + s);
            }
            System.out.print("ID de sucursal: ");
            int idSucursal = scanner.nextInt();
            scanner.nextLine();

            Sucursal sucursal = sistema.buscarSucursalPorId(idSucursal);
            if (sucursal == null) {
                System.out.println("Error: sucursal no encontrada.");
                return;
            }

            Tecnico tecnico = new Tecnico(nombre, apellido, telefono,
                                          username, password,
                                          especializacion, sucursal);
            sistema.agregarTecnico(tecnico);
            System.out.println("Técnico registrado correctamente:");
            tecnico.mostrarInfo();

        } catch (IllegalArgumentException e) {
            System.out.println("Error al registrar técnico: " + e.getMessage());
        } catch (InputMismatchException e) {
            System.out.println("Error: valor inválido ingresado.");
            scanner.nextLine();
        }
    }

    private static void listarTecnicosPorSucursal() {
        System.out.println("\n-- Técnicos por Sucursal --");
        System.out.println("Sucursales disponibles:");
        for (Sucursal s : sistema.getSucursales()) {
            System.out.println("  " + s);
        }
        System.out.print("ID de sucursal: ");
        try {
            int idSucursal = scanner.nextInt();
            scanner.nextLine();
            List<Tecnico> tecnicos = sistema.buscarTecnicosPorSucursal(idSucursal);
            if (tecnicos.isEmpty()) {
                System.out.println("No hay técnicos activos en esa sucursal.");
                return;
            }
            for (Tecnico t : tecnicos) {
                t.mostrarInfo();
            }
        } catch (InputMismatchException e) {
            System.out.println("Error: ingrese un número válido.");
            scanner.nextLine();
        }
    }

    private static void buscarTecnicoPorNombre() {
        System.out.println("\n-- Buscar Técnico por Nombre --");
        System.out.print("Ingrese nombre o apellido: ");
        String nombre = scanner.nextLine();
        List<Tecnico> resultado = sistema.buscarTecnicosPorNombre(nombre);
        if (resultado.isEmpty()) {
            System.out.println("No se encontraron técnicos con ese nombre.");
            return;
        }
        System.out.println("Resultados encontrados: " + resultado.size());
        for (Tecnico t : resultado) {
            t.mostrarInfo();
        }
    }

    private static void verCargaTecnicos() {
        System.out.println("\n-- Carga de Trabajo por Técnico (menor a mayor) --");
        List<Tecnico> ordenados = sistema.ordenarTecnicosPorCarga();
        if (ordenados.isEmpty()) {
            System.out.println("No hay técnicos registrados.");
            return;
        }
        for (Tecnico t : ordenados) {
            System.out.println(t);
        }
    }

    // ========================
    // MÓDULO ÓRDENES
    // ========================

    private static void menuOrdenes() {
        int opcion = -1;
        do {
            System.out.println("\n--- MÓDULO ÓRDENES DE SERVICIO ---");
            System.out.println("1. Registrar ticket");
            System.out.println("2. Crear orden desde ticket");
            System.out.println("3. Asignar técnico a orden");
            System.out.println("4. Cambiar estado de orden");
            System.out.println("5. Listar órdenes por estado");
            System.out.println("6. Ver detalle de orden");
            System.out.println("7. Auditar orden");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            try {
                opcion = scanner.nextInt();
                scanner.nextLine();
                switch (opcion) {
                    case 1: registrarTicket(); break;
                    case 2: crearOrdenDesdeTicket(); break;
                    case 3: asignarTecnicoAOrden(); break;
                    case 4: cambiarEstadoOrden(); break;
                    case 5: listarOrdenesPorEstado(); break;
                    case 6: verDetalleOrden(); break;
                    case 7: auditarOrden(); break;
                    case 0: break;
                    default: System.out.println("Opción inválida.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Error: ingrese un número válido.");
                scanner.nextLine();
            }
        } while (opcion != 0);
    }

    private static void registrarTicket() {
        System.out.println("\n-- Registrar Ticket --");
        try {
            System.out.println("Clientes disponibles:");
            for (Cliente c : sistema.getClientes()) {
                System.out.println("  " + c);
            }
            System.out.print("ID de cliente: ");
            int idCliente = scanner.nextInt();
            scanner.nextLine();

            Cliente cliente = sistema.buscarClientePorId(idCliente);
            if (cliente == null) {
                System.out.println("Error: cliente no encontrado.");
                return;
            }

            System.out.print("Descripción del problema: ");
            String descripcion = scanner.nextLine();

            System.out.print("Prioridad (BAJA/MEDIA/ALTA/URGENTE): ");
            String pStr = scanner.nextLine().toUpperCase();
            Prioridad prioridad;
            try {
                prioridad = Prioridad.valueOf(pStr);
            } catch (IllegalArgumentException e) {
                System.out.println("Prioridad inválida, se asignará MEDIA por defecto.");
                prioridad = Prioridad.MEDIA;
            }

            Ticket ticket = new Ticket(cliente, descripcion, prioridad, "CAT");
            sistema.agregarTicket(ticket);
            System.out.println("Ticket registrado correctamente:");
            ticket.mostrarInfo();

        } catch (InputMismatchException e) {
            System.out.println("Error: valor inválido ingresado.");
            scanner.nextLine();
        } catch (IllegalArgumentException e) {
            System.out.println("Error al registrar ticket: " + e.getMessage());
        }
    }

    private static void crearOrdenDesdeTicket() {
        System.out.println("\n-- Crear Orden desde Ticket --");
        try {
            System.out.println("Tickets pendientes:");
            boolean hayPendientes = false;
            for (Ticket t : sistema.getTickets()) {
                if (t.getEstado() == EstadoTicket.PENDIENTE) {
                    t.mostrarInfo();
                    hayPendientes = true;
                }
            }
            if (!hayPendientes) {
                System.out.println("No hay tickets pendientes de conversión.");
                return;
            }

            System.out.print("ID de ticket a convertir: ");
            int idTicket = scanner.nextInt();
            scanner.nextLine();

            Ticket ticket = sistema.buscarTicketPorId(idTicket);
            if (ticket == null) {
                System.out.println("Error: ticket no encontrado.");
                return;
            }

            System.out.print("Tipo de servicio (INSTALACION/REPARACION/CAMBIO_EQUIPO/MANTENIMIENTO): ");
            TipoServicio tipo = TipoServicio.valueOf(scanner.nextLine().toUpperCase());

            System.out.print("Prioridad (BAJA/MEDIA/ALTA/URGENTE): ");
            Prioridad prioridad = Prioridad.valueOf(scanner.nextLine().toUpperCase());

            System.out.println("Sucursales disponibles:");
            for (Sucursal s : sistema.getSucursales()) {
                System.out.println("  " + s);
            }
            System.out.print("ID de sucursal: ");
            int idSucursal = scanner.nextInt();
            scanner.nextLine();

            Sucursal sucursal = sistema.buscarSucursalPorId(idSucursal);
            if (sucursal == null) {
                System.out.println("Error: sucursal no encontrada.");
                return;
            }

            System.out.print("Observaciones (Enter para omitir): ");
            String obs = scanner.nextLine();

            OrdenServicio orden = ticket.convertirAOrden(tipo, prioridad,
                                                         sucursal,
                                                         obs.isEmpty() ? null : obs);
            sistema.agregarOrden(orden);
            System.out.println("Orden creada correctamente:");
            orden.mostrarInfo();

        } catch (IllegalArgumentException e) {
            System.out.println("Error: valor inválido - " + e.getMessage());
        } catch (IllegalStateException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (InputMismatchException e) {
            System.out.println("Error: ingrese un número válido.");
            scanner.nextLine();
        }
    }

    private static void asignarTecnicoAOrden() {
        System.out.println("\n-- Asignar Técnico a Orden --");
        try {
            System.out.println("Órdenes sin asignar:");
            List<OrdenServicio> sinAsignar = sistema.buscarOrdenesPorEstado(
                                             EstadoOrden.SIN_ASIGNAR);
            if (sinAsignar.isEmpty()) {
                System.out.println("No hay órdenes sin asignar.");
                return;
            }
            for (OrdenServicio o : sinAsignar) {
                o.mostrarResumen();
            }

            System.out.print("Número de orden (ej: ORD-2026-0001): ");
            String numOrden = scanner.nextLine();
            OrdenServicio orden = sistema.buscarOrdenPorNumero(numOrden);
            if (orden == null) {
                System.out.println("Error: orden no encontrada.");
                return;
            }

            System.out.println("Técnicos disponibles (ordenados por carga):");
            List<Tecnico> ordenados = sistema.ordenarTecnicosPorCarga();
            for (Tecnico t : ordenados) {
                System.out.println("  " + t);
            }

            System.out.print("ID de técnico: ");
            int idTecnico = scanner.nextInt();
            scanner.nextLine();

            Tecnico tecnico = sistema.buscarTecnicoPorId(idTecnico);
            if (tecnico == null) {
                System.out.println("Error: técnico no encontrado.");
                return;
            }

            System.out.print("Fecha coordinada (ej: 2026-06-15 10:00): ");
            String fecha = scanner.nextLine();

            orden.asignarTecnico(tecnico, fecha);

        } catch (IllegalArgumentException | IllegalStateException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (InputMismatchException e) {
            System.out.println("Error: ingrese un número válido.");
            scanner.nextLine();
        }
    }

    private static void cambiarEstadoOrden() {
        System.out.println("\n-- Cambiar Estado de Orden --");
        try {
            System.out.print("Número de orden: ");
            String numOrden = scanner.nextLine();
            OrdenServicio orden = sistema.buscarOrdenPorNumero(numOrden);
            if (orden == null) {
                System.out.println("Error: orden no encontrada.");
                return;
            }
            orden.mostrarResumen();
            System.out.println("Estados posibles: CONFIRMADA / EN_CAMINO / EN_SITIO / RESUELTA / POSPUESTA");
            System.out.print("Nuevo estado: ");
            EstadoOrden nuevoEstado = EstadoOrden.valueOf(scanner.nextLine().toUpperCase());
            orden.cambiarEstado(nuevoEstado);

        } catch (IllegalArgumentException e) {
            System.out.println("Error: estado inválido - " + e.getMessage());
        } catch (IllegalStateException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void listarOrdenesPorEstado() {
        System.out.println("\n-- Listar Órdenes por Estado --");
        System.out.println("Estados: SIN_ASIGNAR / ASIGNADA / CONFIRMADA / EN_CAMINO / EN_SITIO / RESUELTA / PENDIENTE_AUDITORIA / CERRADA / POSPUESTA");
        System.out.print("Estado a filtrar: ");
        try {
            EstadoOrden estado = EstadoOrden.valueOf(scanner.nextLine().toUpperCase());
            List<OrdenServicio> resultado = sistema.buscarOrdenesPorEstado(estado);
            if (resultado.isEmpty()) {
                System.out.println("No hay órdenes en estado " + estado);
                return;
            }
            System.out.println("Órdenes en estado " + estado + ":");
            for (OrdenServicio o : resultado) {
                o.mostrarResumen();
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Error: estado inválido.");
        }
    }

    private static void verDetalleOrden() {
        System.out.println("\n-- Detalle de Orden --");
        System.out.print("Número de orden: ");
        String numOrden = scanner.nextLine();
        OrdenServicio orden = sistema.buscarOrdenPorNumero(numOrden);
        if (orden == null) {
            System.out.println("Orden no encontrada.");
            return;
        }
        orden.mostrarInfo();
    }

    private static void auditarOrden() {
        System.out.println("\n-- Auditar Orden --");
        try {
            List<OrdenServicio> pendientes = sistema.buscarOrdenesPorEstado(
                                            EstadoOrden.PENDIENTE_AUDITORIA);
            if (pendientes.isEmpty()) {
                System.out.println("No hay órdenes pendientes de auditoría.");
                return;
            }
            System.out.println("Órdenes pendientes de auditoría:");
            for (OrdenServicio o : pendientes) {
                o.mostrarResumen();
            }

            System.out.print("Número de orden a auditar: ");
            String numOrden = scanner.nextLine();
            OrdenServicio orden = sistema.buscarOrdenPorNumero(numOrden);
            if (orden == null) {
                System.out.println("Orden no encontrada.");
                return;
            }
            orden.mostrarInfo();

            System.out.print("¿Aprobar cierre? (S/N): ");
            String respuesta = scanner.nextLine().toUpperCase();

            if (respuesta.equals("S")) {
                System.out.print("Observación final (Enter para omitir): ");
                String obs = scanner.nextLine();
                coordinadorActivo.auditarOrden(orden, obs.isEmpty() ? null : obs);
            } else {
                System.out.print("Motivo de rechazo: ");
                String motivo = scanner.nextLine();
                coordinadorActivo.rechazarCierreOrden(orden, motivo);
            }

        } catch (IllegalArgumentException | IllegalStateException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // ========================
    // MÓDULO INVENTARIO
    // ========================

    private static void menuInventario() {
        int opcion = -1;
        do {
            System.out.println("\n--- MÓDULO INVENTARIO ---");
            System.out.println("1. Registrar item");
            System.out.println("2. Consultar stock por sucursal");
            System.out.println("3. Registrar uso de equipamiento en orden");
            System.out.println("4. Ver alertas de stock mínimo");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            try {
                opcion = scanner.nextInt();
                scanner.nextLine();
                switch (opcion) {
                    case 1: registrarItem(); break;
                    case 2: consultarStockPorSucursal(); break;
                    case 3: registrarUsoEquipamiento(); break;
                    case 4: verAlertasStock(); break;
                    case 0: break;
                    default: System.out.println("Opción inválida.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Error: ingrese un número válido.");
                scanner.nextLine();
            }
        } while (opcion != 0);
    }

    private static void registrarItem() {
        System.out.println("\n-- Registrar Item de Inventario --");
        try {
            System.out.print("Código: ");
            String codigo = scanner.nextLine();
            System.out.print("Nombre: ");
            String nombre = scanner.nextLine();
            System.out.print("Categoría (ONU/CABLE/CONECTOR/MESH/HERRAMIENTA/OTRO): ");
            CategoriaItem categoria = CategoriaItem.valueOf(
                                      scanner.nextLine().toUpperCase());
            System.out.print("Unidad de medida (unidad/metro/etc): ");
            String unidad = scanner.nextLine();
            System.out.print("Cantidad disponible: ");
            int cantidad = scanner.nextInt();
            System.out.print("Stock mínimo: ");
            int minimo = scanner.nextInt();
            scanner.nextLine();

            System.out.println("Sucursales disponibles:");
            for (Sucursal s : sistema.getSucursales()) {
                System.out.println("  " + s);
            }
            System.out.print("ID de sucursal: ");
            int idSucursal = scanner.nextInt();
            scanner.nextLine();

            Sucursal sucursal = sistema.buscarSucursalPorId(idSucursal);
            if (sucursal == null) {
                System.out.println("Error: sucursal no encontrada.");
                return;
            }

            ItemInventario item = new ItemInventario(codigo, nombre, categoria,
                                                     cantidad, minimo, sucursal);
            sistema.agregarItem(item);
            System.out.println("Item registrado correctamente:");
            item.mostrarInfo();

        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (InputMismatchException e) {
            System.out.println("Error: valor inválido ingresado.");
            scanner.nextLine();
        }
    }

    private static void consultarStockPorSucursal() {
        System.out.println("\n-- Stock por Sucursal --");
        System.out.println("Sucursales disponibles:");
        for (Sucursal s : sistema.getSucursales()) {
            System.out.println("  " + s);
        }
        System.out.print("ID de sucursal: ");
        try {
            int idSucursal = scanner.nextInt();
            scanner.nextLine();
            List<ItemInventario> items = sistema.buscarInventarioPorSucursal(idSucursal);
            if (items.isEmpty()) {
                System.out.println("No hay items registrados para esa sucursal.");
                return;
            }
            for (ItemInventario item : items) {
                item.mostrarInfo();
            }
        } catch (InputMismatchException e) {
            System.out.println("Error: ingrese un número válido.");
            scanner.nextLine();
        }
    }

    private static void registrarUsoEquipamiento() {
        System.out.println("\n-- Registrar Uso de Equipamiento --");
        try {
            System.out.print("Número de orden: ");
            String numOrden = scanner.nextLine();
            OrdenServicio orden = sistema.buscarOrdenPorNumero(numOrden);
            if (orden == null) {
                System.out.println("Orden no encontrada.");
                return;
            }

            List<UsoEquipamiento> usos = new ArrayList<>();
            String continuar = "S";

            while (continuar.equals("S")) {
                System.out.println("Items disponibles:");
                for (ItemInventario item : sistema.getInventario()) {
                    System.out.println("  " + item);
                }
                System.out.print("Código de item: ");
                String codigo = scanner.nextLine();
                ItemInventario item = sistema.buscarItemPorCodigo(codigo);
                if (item == null) {
                    System.out.println("Item no encontrado.");
                } else {
                    System.out.print("Cantidad utilizada: ");
                    int cantidad = scanner.nextInt();
                    scanner.nextLine();
                    usos.add(new UsoEquipamiento(item, cantidad));
                }
                System.out.print("¿Agregar otro item? (S/N): ");
                continuar = scanner.nextLine().toUpperCase();
            }

            System.out.print("Descripción de la resolución: ");
            String resolucion = scanner.nextLine();
            orden.registrarResolucion(resolucion, usos);

        } catch (IllegalArgumentException | IllegalStateException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (InputMismatchException e) {
            System.out.println("Error: valor inválido.");
            scanner.nextLine();
        }
    }

    private static void verAlertasStock() {
        System.out.println("\n-- Alertas de Stock Mínimo --");
        List<ItemInventario> alertas = sistema.obtenerItemsStockBajo();
        if (alertas.isEmpty()) {
            System.out.println("Todos los items tienen stock suficiente.");
            return;
        }
        System.out.println("Items con stock por debajo del mínimo:");
        for (ItemInventario item : alertas) {
            item.mostrarInfo();
        }
    }

    // ========================
    // DATOS INICIALES
    // ========================

    private static void inicializarDatos() {

        // Sucursales
        Sucursal obera = new Sucursal("Oberá Casa Central", "Oberá",
                                      "Av. Libertad 1234", "3755-12345");
        Sucursal wanda = new Sucursal("Wanda", "Wanda",
                                      "Ruta 19 Km 45", "3757-23456");
        Sucursal sanPedro = new Sucursal("San Pedro", "San Pedro",
                                         "Calle Principal 890", "3751-34567");
        sistema.agregarSucursal(obera);
        sistema.agregarSucursal(wanda);
        sistema.agregarSucursal(sanPedro);

        // Coordinador activo del sistema
        coordinadorActivo = new Coordinador("María", "García", "3755-99999",
                                            "mgarcia", "cat123");

        // Clientes
        Cliente c1 = new Cliente("Carlos", "González", "3755-111111",
                                 "Calle San Martín 456", "Oberá", "cgonzalez@email.com");
        Cliente c2 = new Cliente("Laura", "Martínez", "3757-222222",
                                 "Av. Sarmiento 789", "Wanda");
        Cliente c3 = new Cliente("Pedro", "Sánchez", "3751-333333",
                                 "Ruta 14 Km 23", "San Pedro");
        sistema.agregarCliente(c1);
        sistema.agregarCliente(c2);
        sistema.agregarCliente(c3);

        // Técnicos
        Tecnico t1 = new Tecnico("Roberto", "Gómez", "3755-100001",
                                 "rgomez", "tec123", "FTTH", obera);
        Tecnico t2 = new Tecnico("Marcelo", "Silva", "3755-100002",
                                 "msilva", "tec123", "GENERAL", obera);
        Tecnico t3 = new Tecnico("Fernando", "Ortiz", "3757-100003",
                                 "fortiz", "tec123", "FTTH", wanda);
        sistema.agregarTecnico(t1);
        sistema.agregarTecnico(t2);
        sistema.agregarTecnico(t3);

        // Tickets
        Ticket tk1 = new Ticket(c1, "Sin servicio desde ayer por la tarde",
                                Prioridad.ALTA, "CAT");
        Ticket tk2 = new Ticket(c2, "Velocidad degradada, solo alcanza 50Mbps",
                                Prioridad.MEDIA, "CAT");
        sistema.agregarTicket(tk1);
        sistema.agregarTicket(tk2);

        // Orden desde ticket 1 ya asignada
        OrdenServicio o1 = tk1.convertirAOrden(TipoServicio.REPARACION,
                                               Prioridad.ALTA, obera,
                                               "Verificar OLT y ONT");
        o1.asignarTecnico(t1, "2026-06-10 14:00");
        sistema.agregarOrden(o1);

        // Inventario
        ItemInventario onu1 = new ItemInventario("ONU-HG8310M", "ONU Huawei HG8310M",
                                                 CategoriaItem.ONU, 45, 10, obera);
        ItemInventario cable1 = new ItemInventario("CABLE-UTP-CAT6", "Cable UTP Cat 6",
                                                   "Cable interior cat6",
                                                   CategoriaItem.CABLE, "metro",
                                                   500, 100, obera);
        ItemInventario conector1 = new ItemInventario("CONECTOR-SC-APC", "Conector SC/APC",
                                                      CategoriaItem.CONECTOR, 150, 30, obera);
        ItemInventario onu2 = new ItemInventario("ONU-ZTE-F660", "ONU ZTE F660",
                                                 CategoriaItem.ONU, 3, 8, wanda);
        sistema.agregarItem(onu1);
        sistema.agregarItem(cable1);
        sistema.agregarItem(conector1);
        sistema.agregarItem(onu2);

        System.out.println("Datos iniciales cargados correctamente.");
    }
}